package com.ejemplo.agenda;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AgendaApplicationTests {

	@Test
	void contextLoads() {
	}

}
